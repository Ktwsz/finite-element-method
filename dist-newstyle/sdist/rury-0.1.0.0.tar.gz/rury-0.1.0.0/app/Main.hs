module Main where

import Data.Matrix
import GHC.List as Ghcl (concat)
import GHC.Float (int2Float)

type Function = Float -> Float

type Domain = (Float, Float)

omega :: Domain
omega = (0, 3)

rho :: Function
rho x | 0 <= x && x < 1 = 0
      | 1 <= x && x < 2 = 1
      | 2 <= x && x <= 3 = 0

constPI :: Float
constPI = 3.1415

constG :: Float
constG = 6.6743

gaussIntegral :: [(Float, Float)] -> Function -> Float
gaussIntegral weights f  = sum .
                            map (\(w, x) -> w * f x) $
                            weights


twoPoint :: [(Float, Float)]
twoPoint = [(1, -1 / sqrt 3), (1, 1 / sqrt 3)]

twoPointIntegral :: Function -> Float
twoPointIntegral = gaussIntegral twoPoint

mapCoordinates :: Domain -> Function -> Function
mapCoordinates (a, b) f = \x -> intervalLength * f (intervalLength * x + offset)

    where intervalLength = (b - a) / 2
          offset = (a + b) / 2


partialIntegral :: Domain -> Function -> Float
partialIntegral domain = twoPointIntegral . mapCoordinates domain 

integral :: Int -> Domain -> Function -> Float
integral n (da, db) f = sum .
                        map (\x -> partialIntegral x f) $
                        domainDivided
    where fn = int2Float n 
          domainSize = db - da
          domainDivided = [(int2Float i * (domainSize / fn), int2Float (i + 1) * (domainSize / fn)) | i <- [0..n-1]]


getTest :: Int -> Int -> Function
getTest n k | k == 0    = e_0
            | k == n    = e_n
            | otherwise = e_k

        where fn = int2Float n
              fk = int2Float k * 3 / fn

              e_0 x = if 0 <= x && x < 3/fn then 1 - fn/3 * x else 0

              e_k x | 0 <= x && x < fk - 3/fn = 0
                    | fk - 3/fn <= x && x < fk = fn/3 * x + 1 - fn * fk/3
                    | fk <= x && x < fk + 3/fn = -fn/3 * x + 1 + fn * fk/3
                    | fk + 3/fn < x && x <= 3 = 0

              e_n x = if 3 * ((fn-1)/fn) <= x && x <= 3 then fn/3 * x + 1 - fn else 0

getTestDerivative:: Int -> Int -> Function
getTestDerivative n k | k == 0    = de_0
                      | k == n    = de_n
                      | otherwise = de_k

         where fn = int2Float n
               fk = int2Float k * 3 / fn

               de_0 x = if 0 <= x && x < 3/fn then - fn/3 else 0

               de_k x | 0 <= x && x < fk - 3/fn = 0
                      | fk - 3/fn <= x && x < fk = fn/3
                      | fk <= x && x < fk + 3/fn = -fn/3
                      | fk + 3/fn < x && x <= 3 = 0

               de_n x = if 3 * ((fn-1)/fn) <= x && x <= 3 then fn/3 else 0


getBMatrix :: Int -> Matrix Float
getBMatrix n = scaleMatrix (-1.0) .
                    (<$>) (integral n omega) .
                    fromList (n-1) (n-1) .
                    Ghcl.concat $
                    [[b i j | i <- [1..n-1]] | j <- [1..n-1]]
    where b i j = \x -> getTestDerivative n i x * getTestDerivative n j x 

getLMatrix :: Int -> Matrix Float
getLMatrix n = (<$>) (integral n omega) .
                    fromList (n-1) 1 $ 
                    [l i | i <- [1..n-1]]
    where l i = \x -> 4 * constG * constPI * getTestDerivative n i x * rho x


solve :: Int -> Either String [Float]
solve n = let invertedBMatrix = inverse $ getBMatrix n
              lMatrix = getLMatrix n 
          in case invertedBMatrix of
            Left err -> Left err
            Right m -> Right . toList $ multStd m lMatrix 

saveWeights :: [Float] -> String
saveWeights m = Ghcl.concat . map (\x -> show x ++ "\n") $ m



compute :: Int -> Domain -> [Float] -> [Float]
compute n (a, b) weights = let values = map (\x -> (x + 0.5) / int2Float n * (b - a) + a) [0..int2Float n - 1]
                               base = zipWith (\f w -> (\x -> w * f x)) [getTest n i | i <- [1..n-1]] weights

                           in zipWith ($) base values

main :: IO ()
main = do
    n <- readLn
    let solution = solve (n :: Int)
    case solution of
        Left err -> putStrLn err
        Right weights -> do 
                            putStrLn . saveWeights $ weights
                            putStrLn . saveWeights $ compute n omega weights
    --putStrLn . prettyMatrix $ getBMatrix n
    --putStrLn . saveWeights weights
    --writeFile "output.txt" . Ghcl.concat . map (\x -> show x ++ "\n") $ solve n
